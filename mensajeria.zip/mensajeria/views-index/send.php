<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imagen de Perfil con Fondo Aleatorio</title>
    <style>
        .profile-image {
            width: 50px;
            height: 50px;
            border-radius: 50%; /* Hace que la imagen sea circular */
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px; /* Tamaño del texto */
            color: #ffffff; /* Color del texto */
        }
    </style>
</head>
<body>
    <div class="profile-image" id="profile-image">
        AC <!-- Cambia esto por tus iniciales o contenido deseado -->
    </div>

    <script>
        // Función para generar un color aleatorio en formato hexadecimal
        function generarColorAleatorio() {
            var letras = "0123456789ABCDEF";
            var color = "#";
            for (var i = 0; i < 6; i++) {
                color += letras[Math.floor(Math.random() * 16)];
            }
            return color;
        }

        // Cambia el fondo de la imagen de perfil a un color aleatorio
        function cambiarFondoAleatorio() {
            var profileImage = document.getElementById("profile-image");
            var colorAleatorio = generarColorAleatorio();
            profileImage.style.backgroundColor = colorAleatorio;
        }

        // Llama a la función para cambiar el fondo al cargar la página
        cambiarFondoAleatorio();
    </script>
</body>
</html>
