<?php
session_start();
use MyApp\data\Database;
require("../vendor/autoload.php");
$db = new Database();



//Actualizar o subir foto de perfil
if(isset($_POST['subir_imagen'])){
    // Verificar si se ha seleccionado una nueva imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen_nombre = $_FILES['imagen']['name'];
        $imagen_temporal = $_FILES['imagen']['tmp_name'];
        $id_usuario = $_POST['id_usuario'];


        // Directorio donde deseas guardar las imágenes
        $directorio_destino = "img_profile/"; // Cambia esto a la ruta correcta

        // Ruta completa del archivo de destino
        $ruta_destino = $directorio_destino . $imagen_nombre;

        

        //Borrar imagen actual del usuario para poner una nueva
        $imagen=$db->seleccionarDatos("SELECT imagen FROM `usuarios` where id_usuario=".$id_usuario);
        //borrar la imagen temporal (de la carpeta)
        foreach($imagen as $img){
            $image=$img['imagen'];
        }
        unlink("img_profile/".$image);





        // Mover la imagen al directorio de destino
        if (move_uploaded_file($imagen_temporal, $ruta_destino)) {
            // Configurar la conexión PDO (debes llenar los detalles de conexión)
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "mensajeria";

            try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                // Preparar la consulta SQL para actualizar la imagen en la base de datos
                $sql = "UPDATE usuarios SET imagen = :imagen WHERE id_usuario = :id_usuario";

                // Preparar la consulta usando PDO
                $stmt = $conn->prepare($sql);

                // Vincular los valores a los marcadores de posición
                $stmt->bindParam(':imagen', $imagen_nombre, PDO::PARAM_STR);
                $stmt->bindParam(':id_usuario', $id_usuario, PDO::PARAM_INT);

                // Ejecutar la consulta
                if ($stmt->execute()) {

                } else {
                    echo "Error al actualizar la imagen en la base de datos: " . $stmt->errorInfo()[2];
                }
            } catch (PDOException $e) {
                echo "Error de base de datos: " . $e->getMessage();
            }

            // Cerrar la conexión
            $conn = null;
        } else {
            echo "Error al mover la imagen al directorio de destino.";
        }
    } else {
        echo "Error al subir la nueva imagen.";
    }

}

//Actualizar datos personales
if(isset($_POST['guardar_datos_personales'])){

    $nombre_nuevo=$_POST['nombre'];
    $apellido_nuevo=$_POST['apellido'];
    $correo_nuevo=$_POST['correo'];
    $info_nuevo=$_POST['info'];

        //Actualizar nombre
        $update_nombre_nuveo = "UPDATE personas 
        INNER JOIN usuarios ON usuarios.id_persona = personas.id_persona
        SET personas.nombre = '$nombre_nuevo' 
        WHERE usuarios.id_usuario=$_SESSION[id] ";
        $update_nombre=$db->ejecutarConsulta($update_nombre_nuveo);

        //Actualizar apellido
        $update_apellido_nuveo = "UPDATE personas 
        INNER JOIN usuarios ON usuarios.id_persona = personas.id_persona
        SET personas.apellido = '$apellido_nuevo' 
        WHERE usuarios.id_usuario=$_SESSION[id] ";
        $update_apellido=$db->ejecutarConsulta($update_apellido_nuveo);

        //Actualizar correo
        $update_correo_nuveo = "UPDATE personas 
        INNER JOIN usuarios ON usuarios.id_persona = personas.id_persona
        SET personas.correo = '$correo_nuevo' 
        WHERE usuarios.id_usuario=$_SESSION[id] ";
        $update_correo=$db->ejecutarConsulta($update_correo_nuveo);

        //Actualizar info
        $update_info_nuveo = "UPDATE personas 
        INNER JOIN usuarios ON usuarios.id_persona = personas.id_persona
        SET personas.info = '$info_nuevo' 
        WHERE usuarios.id_usuario=$_SESSION[id] ";
        $update_info=$db->ejecutarConsulta($update_info_nuveo);



}
 



//Actualizar contraseña
if(isset($_POST['guardar_contrasena'])){

$contrasena_actual=$_POST['contrasena_actual'];
$contrasena_nueva=$_POST['nueva_contrasena'];
$confirmar_contrasena=$_POST['confirmar_contrasena'];

//verificar contraseña actual
  // Consulta SQL para consultar el hash password
  $sql = "SELECT * FROM usuarios  INNER JOIN personas on personas.id_persona=usuarios.id_persona WHERE usuarios.id_usuario=$_SESSION[id]";
  $verificacion_login = $db->seleccionarDatos($sql);

  //obtener hash
  foreach ($verificacion_login as $passwd){
      $hash= $passwd['contrasena'];
        if(password_verify($contrasena_actual, $hash)){
                //Verificar contraseña nueva
                if($contrasena_nueva==$confirmar_contrasena){
                     // Generar un hash de contraseña segura
                    $hash_contrasena = password_hash($confirmar_contrasena, PASSWORD_DEFAULT);

                    // Consulta de actualización de contraseña
                    $sql = "UPDATE usuarios SET contrasena = '$hash_contrasena' WHERE id_usuario=$_SESSION[id]";
                    $db->ejecutarConsulta($sql);

                }

        }
    }
}

if (isset($_SESSION['id'])) {

    $sql="select * from usuarios inner join personas on personas.id_persona=usuarios.id_persona where usuarios.id_usuario=$_SESSION[id]";
    $datos_usuario=$db->seleccionarDatos($sql);

    //sacar datos del usuario
    foreach ($datos_usuario as $usuario){
        $nombre=$usuario['nombre'];
        $apellido=$usuario['apellido'];
        $correo=$usuario['correo'];
        $info=$usuario['info'];
        $img=$usuario['imagen'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap/css/dark-mode.css">
    <link rel="stylesheet" href="../bootstrap/css/light-mode.css">
    <link rel="stylesheet" href="../bootstrap/css/estilos.css">
    <!--Boostrap-->   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
<!--Boostrap--> 
</head>
<style>
    input[type="file"] {
    display: none;
}
.imagen-preview {
    margin: auto;
    max-width: 60px; /* Cambiamos max-width a 60px */
    max-height: 60px; /* Cambiamos max-height a 60px */
    width: 60px; /* Usamos width al 100% para que la imagen se ajuste al contenedor */
    height: 60px; /* Usamos height al 100% para que la imagen se ajuste al contenedor */
    border-radius: 50%;
    border: 0px solid #0d6efd;
    position: relative;
    top: 0px;
    background-color: #2787f552;
    object-fit: cover; /* Añadimos object-fit para que la imagen se ajuste correctamente */
}

.imagen-preview img {
  margin: auto;
  max-width: 100%;
  max-height: 100%;
  width: 75px;
  height: 75px;
  border-radius:50%;
}
</style>

<body id="body" class="dark-mode" style="margin: 3%;">
    

<!--Pantalla de bienvenida cargando-->
<div class="loading-overlay" id="loadingOverlay">
    <h1 style="position:fixed; top: 220px; font-weight: bolder; color: white;">Configuración </h1>

    <div class='demo'>
        <div class='circle'>
          <div class='inner'></div>
        </div>
        <div class='circle'>
          <div class='inner'></div>
        </div>
        <div class='circle'>
          <div class='inner'></div>
        </div>
        <div class='circle'>
          <div class='inner'></div>
        </div>
        <div class='circle'>
          <div class='inner'></div>
        </div>
      </div>
</div>


<script>
    const loadingOverlay = document.getElementById('loadingOverlay');

    // Mostrar la pantalla de carga
    loadingOverlay.style.pointerEvents = 'auto'; // Permite interactuar con la pantalla de carga
    setTimeout(() => {
        loadingOverlay.style.opacity = '0';
        loadingOverlay.style.backdropFilter = 'blur(30px)'; // Agrega difuminado al desvanecer
    }, 1000); // Cambiar el tiempo según tus necesidades
    // Después de 5 segundos (2 segundos para la animación), ocultar la pantalla de carga
    setTimeout(() => {
        loadingOverlay.style.display = 'none';
    }, 2000); // Cambiar el tiempo según tus necesidades
</script>

<!--Pantalla de bienvenida cargando-->





<div class="floating-bar">
    <div class="row">
        <div class="col-2 text-center">
            <a href="">
                <svg fill="#0a85f0" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
                  </svg>
            </a>
        </div>
        <div class="col-8 text-center ">
            <p>Configuración de Cuenta</p>
        </div>
        <div class="col-2">
            <button type="button" name="dark_light" onclick="toggleDarkLight()" >
                <svg id="change-theme" xmlns="http://www.w3.org/2000/svg" width="18" height="18"  class="bi bi-sun" viewBox="0 0 16 16">
                    <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
                  </svg>
            </button>

        </div>
    </div>
</div>



<div class="floating-bar-bottom">
    <div class="row text-center">
        <div class="col-3">
            <a href="no_leidos.html" class="a">
            <svg  id="icon_bar" xmlns="http://www.w3.org/2000/svg" width="20" height="20" class="bi bi-bookmark-dash" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M5.5 6.5A.5.5 0 0 1 6 6h4a.5.5 0 0 1 0 1H6a.5.5 0 0 1-.5-.5z"/>
                <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"/>
              </svg>
              <p id="icon_bar"  style="font-size: 10px;">No leidos</p>
            </a>
        </div>


        <div class="col-3">
            <a href="archivados.php" class="a">
            <svg  id="icon_bar"  xmlns="http://www.w3.org/2000/svg" width="20" height="20"  class="bi bi-archive" viewBox="0 0 16 16">
                <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
              </svg>
              <p id="icon_bar"  style="font-size: 10px;">Archivados</p>
            </a>
        </div>


        <div class="col-3">
            <a href="index.php" class="a">
            <svg id="icon_bar" xmlns="http://www.w3.org/2000/svg" width="20" height="20"  class="bi bi-chat" viewBox="0 0 16 16">
                <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z"/>
              </svg>
              <p id="icon_bar"  style="font-size: 10px;">Chats</p>
            </a>
        </div>
 

        <div class="col-3">
            <a href="" class="a">
            <svg  fill="#0a85f0"   xmlns="http://www.w3.org/2000/svg" width="20" height="20"  class="bi bi-gear-wide-connected" viewBox="0 0 16 16">
                <path d="M7.068.727c.243-.97 1.62-.97 1.864 0l.071.286a.96.96 0 0 0 1.622.434l.205-.211c.695-.719 1.888-.03 1.613.931l-.08.284a.96.96 0 0 0 1.187 1.187l.283-.081c.96-.275 1.65.918.931 1.613l-.211.205a.96.96 0 0 0 .434 1.622l.286.071c.97.243.97 1.62 0 1.864l-.286.071a.96.96 0 0 0-.434 1.622l.211.205c.719.695.03 1.888-.931 1.613l-.284-.08a.96.96 0 0 0-1.187 1.187l.081.283c.275.96-.918 1.65-1.613.931l-.205-.211a.96.96 0 0 0-1.622.434l-.071.286c-.243.97-1.62.97-1.864 0l-.071-.286a.96.96 0 0 0-1.622-.434l-.205.211c-.695.719-1.888.03-1.613-.931l.08-.284a.96.96 0 0 0-1.186-1.187l-.284.081c-.96.275-1.65-.918-.931-1.613l.211-.205a.96.96 0 0 0-.434-1.622l-.286-.071c-.97-.243-.97-1.62 0-1.864l.286-.071a.96.96 0 0 0 .434-1.622l-.211-.205c-.719-.695-.03-1.888.931-1.613l.284.08a.96.96 0 0 0 1.187-1.186l-.081-.284c-.275-.96.918-1.65 1.613-.931l.205.211a.96.96 0 0 0 1.622-.434l.071-.286zM12.973 8.5H8.25l-2.834 3.779A4.998 4.998 0 0 0 12.973 8.5zm0-1a4.998 4.998 0 0 0-7.557-3.779l2.834 3.78h4.723zM5.048 3.967c-.03.021-.058.043-.087.065l.087-.065zm-.431.355A4.984 4.984 0 0 0 3.002 8c0 1.455.622 2.765 1.615 3.678L7.375 8 4.617 4.322zm.344 7.646.087.065-.087-.065z"/>
              </svg>
              <p   style="font-size: 10px; color: #0a85f0;">Configuración</p>
            </a>
        </div>
    </div>
</div>




<div style="margin-top: 60px;">
    <h1 id="chats">Configuración</h1>
<br>
    <div>
        <div id="back_form"  class="chat-container" >
    <!-- Formulario para seleccionar y cargar una imagen -->
    <form action="" method="post" enctype="multipart/form-data" style="display:contents;margin-top: 0;">
        <input for="imagen" type="file" id="imagen" name="imagen" accept="image/*" onchange="mostrarImagen(event)" class="input-image">
        <input type="hidden" name="id_usuario" value="<?php echo $_SESSION['id']; ?>">
    

    <!-- Vista previa de la imagen -->
    <style>
.feather-image {
  display: inline-block; /* Mostrar SVG por defecto */
}
</style>

<label for="imagen" class="label-imagen">
  <div id="imagen-preview" class="imagen-preview">
    <img  id="imagen-preview" src="img_profile/<?php echo $img;?>"   onerror="this.style.display='none';" onload="">
    <center>
      <label for="imagen" class="label-imagen">
        <svg style="position:relative; top:-13px; left:-20px; margin:auto; background:#2787f552; border-radius:50%; padding:5%"  xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="#0d6efd" class="bi bi-cloud-plus" viewBox="0 0 16 16"  stroke="##0d6efd" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image">
  <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 .5-.5z"/>
  <path d="M4.406 3.342A5.53 5.53 0 0 1 8 2c2.69 0 4.923 2 5.166 4.579C14.758 6.804 16 8.137 16 9.773 16 11.569 14.502 13 12.687 13H3.781C1.708 13 0 11.366 0 9.318c0-1.763 1.266-3.223 2.942-3.593.143-.863.698-1.723 1.464-2.383zm.653.757c-.757.653-1.153 1.44-1.153 2.056v.448l-.445.049C2.064 6.805 1 7.952 1 9.318 1 10.785 2.23 12 3.781 12h8.906C13.98 12 15 10.988 15 9.773c0-1.216-1.02-2.228-2.313-2.228h-.5v-.5C12.188 4.825 10.328 3 8 3a4.53 4.53 0 0 0-2.941 1.1z"/>
</svg>
    </center>
  </div>
</label>


    <script>
        function mostrarImagen(event) {
            const input = event.target;
            const preview = document.getElementById('imagen-preview');
            const guardarImagen = document.getElementById('guardarImagen');

            const reader = new FileReader();

            reader.onload = function() {
                const imagen = document.createElement('img');
                imagen.src = reader.result;
                preview.innerHTML = '';
                preview.appendChild(imagen);

                // Mostrar el botón para guardar imagen
                guardarImagen.style.display = 'block';
            }

            reader.readAsDataURL(input.files[0]);
        }
    </script>


    
&ensp;&ensp;
            <div class="chat-content text-truncate">
                <div class="chat-header">
                    <h2 class="text-truncate" id="nombrechat"><?php echo $nombre ?></h2>
                    <div style="font-size: 12px;color: #c1c1c1; margin-top: -1%;">
                        
                        <svg style="margin-right:10px" version="1.1" width="22px" height="22px" fill="#2787f5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 46 46" enable-background="new 0 0 46 46" xml:space="preserve">
                        <polygon opacity="0.7" points="45,11 36,11 35.5,1 "></polygon>
                        <polygon points="35.5,1 25.4,14.1 39,21 "></polygon>
                        <polygon opacity="0.4" points="17,9.8 39,21 17,26 "></polygon>
                        <polygon opacity="0.7" points="2,12 17,26 17,9.8 "></polygon>
                        <polygon opacity="0.7" points="17,26 39,21 28,36 "></polygon>
                        <polygon points="28,36 4.5,44 17,26 "></polygon>
                        <polygon points="17,26 1,26 10.8,20.1 "></polygon>
                    </svg></div>
                </div>
                <div class="text-truncate" id="mensajechat" ><?php echo $info ?></div>
                <br> 
       <!-- Botón para guardar imagen (inicialmente oculto) -->
       <button type="submit" id="guardarImagen" style="display: none; margin-left: 0%; border:none; border-radius:10px; background-color: #0071e3; color: white; padding: 10px 25px;" name="subir_imagen">Guardar Imagen</button>
       </form>
            </div>
            <br><br>
        </div>
        

        

<br>
        <span id="span"  >Cuenta</span>
<br><br>


<form action="" method="post">
        <div id="back_form" class="chat-container">
            <div class="chat-content text-truncate">
                <h2 class="text-truncate" id="nombrechat">Configuración de Perfil</h2>
                <div class="text-truncate" id="mensajechat" >Cambia la Configuraciónde tu Perfil</div>
                <br>
                <hr style="width:96%; margin:auto; color:#95aac9; opacity:0.2; margin-bottom:3%">
            

            <div class="row">
                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating">
                        <input  type="text" class=" form-control input inputt " id="floatingInput" name="nombre" value="<?php echo $nombre ?>" required>
                        <label for="floatingInput">Nombre 
                        </label> 
                    </div>
                </div>

                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating">
                        <input   type="text" class="form-control input inputt" id="floatingInput" name="apellido" value="<?php echo $apellido ?>"  required>
                        <label for="floatingInput">Apellido
                        </label> 
                    </div>
                </div>


                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating">
                        <input  type="email" class="form-control input inputt" id="floatingInput" name="correo" value="<?php echo $correo ?>"  required>
                        <label for="floatingInput">Correo electrónico
                        </label> 
                    </div>
                </div>


                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating">
                        <input     type="text" class="form-control input inputt" id="floatingInput" name="info" value="<?php echo $info ?>"  required>
                        <label for="floatingInput">Información de estado
                        </label> 
                    </div>
                </div>

                <br><br><br><br>
            </div>

            <button type="submit" name="guardar_datos_personales" class="boton">Guardar </button>



            </div>
        </div>
        </form>



        <br><br>
        <span id="span"  >Seguridad</span>
<br><br>

<form action="" method="post">
        <div id="back_form" class="chat-container">
            <div class="chat-content text-truncate">
                <h2 class="text-truncate" id="nombrechat">Contraseña</h2>
                <div class="text-truncate" id="mensajechat" >Actualice su contraseña</div>
                <br>
                <hr style="width:96%; margin:auto; color:#95aac9; opacity:0.2; margin-bottom:3%">
            

            <div class="row">
                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating" >
                       
                                <input style="padding-right: 15%;" type="password" class="form-control input inputt" id="passwordInput" name="contrasena_actual" required>
                                <label for="passwordInput">Contraseña actual</label>
                                <svg style="position:relative;left: 88%; top:-46px" onclick="mostrarContrasena()" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#0d6efd" class="bi bi-eye" viewBox="0 0 16 16">
                                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                                </svg>
                      
                    </div>
                    <script>
                        function mostrarContrasena() {
    var passwordInput = document.getElementById("passwordInput");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
    } else {
        passwordInput.type = "password";
    }
}
                    </script>
            
                </div>


                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating" >
                       
                                <input style="padding-right: 15%;"  type="password" class="form-control input inputt" id="passwordInput2" name="nueva_contrasena" required>
                                <label for="passwordInput2">Nueva Contraseña </label>
                                <svg style="position:relative;left: 88%; top:-46px" onclick="mostrarContrasena2()" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#0d6efd" class="bi bi-eye" viewBox="0 0 16 16">
                                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                                </svg>
                      
                    </div>
                    <script>
                        function mostrarContrasena2() {
    var passwordInput2 = document.getElementById("passwordInput2");

    if (passwordInput2.type === "password") {
        passwordInput2.type = "text";
    } else {
        passwordInput2.type = "password";
    }
}
                    </script>
            
                </div>


                <div class="col-12 col-md-6" style="padding-top: 8px;">
                    <div class="form-floating" >
                       
                                <input style="padding-right: 15%;"   type="password" class="form-control input inputt" id="passwordInput3" name="confirmar_contrasena" required>
                                <label for="passwordInput3">Confime la contraseña </label>
                                <svg style="position:relative;left: 88%; top:-46px" onclick="mostrarContrasena3()" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="#0d6efd" class="bi bi-eye" viewBox="0 0 16 16">
                                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                                </svg>
                      
                    </div>
                    <script>
                        function mostrarContrasena3() {
    var passwordInput3 = document.getElementById("passwordInput3");

    if (passwordInput3.type === "password") {
        passwordInput3.type = "text";
    } else {
        passwordInput3.type = "password";
    }
}
                    </script>
            
                </div>


                <br><br><br><br>
            </div>

            <button type="submit" name="guardar_contrasena" class="boton">Guardar </button>



            </div>
        </div>
        </form>


        <br><br>
        <a href="../src/scripts/logout.php">
    <button style="width:60%; margin-left:20%; margin-right:20%; padding:15px; color:white; background-color: red; border-radius: 10px;" type="button">Cerrar Session</button>
    </a>
<br><br>







    </div>
<br><br><br>


</div>




<?php
?>
<style>
 
.notification-container {
    position: fixed;
    bottom: 8%;
    left: 22%;
    width: 75%;
    margin-left: 3px;
    background-color: rgba(255, 255, 255, 0.419);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    margin-right: 0;
    overflow: hidden;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
/* Nuevo contenedor debajo del contenedor principal */
.additional-container {
    position: fixed;
    left: 23.5%;
    width: 73%;
    bottom: 7%;
    height: 100px;
    backdrop-filter: blur(10px);
    background-color: rgba(255, 255, 255, 0.419);
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
.additional-container2 {
    position: fixed;
    left: 25.5%;
    width: 70%;
    bottom: 6%;
    backdrop-filter: blur(60px);
    height: 100px;
    background-color: rgba(255, 255, 255, 0.419);
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
/* Lista de notificaciones */
.notification-list {
    padding: 10px;
}

/* Estilo de cada notificación */
.notification-item {
    padding: 10px;
    display: flex;
    align-items: center;
    transition: background-color 0.3s;
}


.notification-content {
    flex-grow: 1;
}
.notification-container {
    position: fixed;
    bottom: 14%;
    left: 22%;
    width: 75%;
    margin-left: 3px;
    background-color: rgba(255, 255, 255, 0.419);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    margin-right: 0;
    overflow: hidden;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
/* Nuevo contenedor debajo del contenedor principal */
.additional-container {
    position: fixed;
    left: 23.5%;
    width: 73%;
    bottom: 13%;
    height: 100px;
    backdrop-filter: blur(10px);
    background-color: rgba(255, 255, 255, 0.419);
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
.additional-container2 {
    position: fixed;
    left: 25.5%;
    width: 70%;
    bottom: 12%;
    backdrop-filter: blur(60px);
    height: 100px;
    background-color: rgba(255, 255, 255, 0.419);
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}
/* Lista de notificaciones */
.notification-list {
    padding: 10px;
}

/* Estilo de cada notificación */
.notification-item {
    padding: 10px;
    display: flex;
    align-items: center;
    transition: background-color 0.3s;
}


.notification-content {
    flex-grow: 1;
}
</style>
<?php


// Notificaciones
if(isset($_POST['guardar_contrasena'])){
    if(password_verify($contrasena_actual, $hash)){
        if($contrasena_nueva==$confirmar_contrasena){
            
?>

<div class="additional-container2" id="contenedor2">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>
    <!-- Nuevo contenedor debajo del contenedor principal -->
    <div class="additional-container" id="contenedor1">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>

    <div class="notification-container" id="contenedor">
        <div class="notification-list">
            <!-- Ejemplo de notificaciones -->
            <div class="notification-item">
                <div class="notification-content">
                    <span class="d-block d-md-none" style="position: fixed; left:80%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <span class="d-none d-md-block" style="position: fixed; left:89%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <strong style="color:black">Notificación</strong>
                    <p style="position: relative; top: 5px; color: #2f2e2e">Contraseña actualizada. <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#198754" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
</svg></p>
                </div>
            </div>
        </div>
    </div>


    <audio id="notificationSound" preload="auto">
        <source src="../src/files/notificacion/notificacion.mp3" type="audio/mpeg">
        <!-- Agrega otros formatos de audio si es necesario -->
    </audio>
    <script>
        // Muestra la notificación
        document.getElementById('contenedor').style.display = 'block';

        // Reproduce el sonido
        var audio = document.getElementById('notificationSound');
        audio.play();
    </script>

    <script>
        function ocultarContenedores() {
            // Ocultar los contenedores con JavaScript
            document.getElementById('contenedor1').style.display = 'none';
            document.getElementById('contenedor2').style.display = 'none';
            document.getElementById('contenedor').style.display = 'none';
        }
    </script>
                    <?php
        }
        else{
            ?>
           <div class="additional-container2" id="contenedor2">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>
    <!-- Nuevo contenedor debajo del contenedor principal -->
    <div class="additional-container" id="contenedor1">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>

    <div class="notification-container" id="contenedor">
        <div class="notification-list">
            <!-- Ejemplo de notificaciones -->
            <div class="notification-item">
                <div class="notification-content">
                    <span class="d-block d-md-none" style="position: fixed; left:80%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <span class="d-none d-md-block" style="position: fixed; left:89%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <strong style="color:black">Notificación</strong>
                    <p style="position: relative; top: 5px; color: #2f2e2e">No coincide la nueva  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#dc3545" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
</svg> </p>
                </div>
            </div>
        </div>
    </div>

    <audio id="notificationSound" preload="auto">
        <source src="../src/files/notificacion/notificacion.mp3" type="audio/mpeg">
        <!-- Agrega otros formatos de audio si es necesario -->
    </audio>
    <script>
        // Muestra la notificación
        document.getElementById('contenedor').style.display = 'block';

        // Reproduce el sonido
        var audio = document.getElementById('notificationSound');
        audio.play();
    </script>
    
    <script>
        function ocultarContenedores() {
            // Ocultar los contenedores con JavaScript
            document.getElementById('contenedor1').style.display = 'none';
            document.getElementById('contenedor2').style.display = 'none';
            document.getElementById('contenedor').style.display = 'none';
        }
    </script>
                <?php
        }
}
else{
    ?>
<div class="additional-container2" id="contenedor2">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>
    <!-- Nuevo contenedor debajo del contenedor principal -->
    <div class="additional-container" id="contenedor1">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>

    <div class="notification-container" id="contenedor">
        <div class="notification-list">
            <!-- Ejemplo de notificaciones -->
            <div class="notification-item">
                <div class="notification-content">
                    <span class="d-block d-md-none" style="position: fixed; left:80%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <span class="d-none d-md-block" style="position: fixed; left:89%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <strong style="color:black">Notificación</strong>
                    <p style="position: relative; top: 5px; color: #2f2e2e">No coincide la actual. <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#dc3545" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
</svg> </p>
                </div>
            </div>
        </div>
    </div>

    <audio id="notificationSound" preload="auto">
        <source src="../src/files/notificacion/notificacion.mp3" type="audio/mpeg">
        <!-- Agrega otros formatos de audio si es necesario -->
    </audio>
    <script>
        // Muestra la notificación
        document.getElementById('contenedor').style.display = 'block';

        // Reproduce el sonido
        var audio = document.getElementById('notificationSound');
        audio.play();
    </script>

    <script>
        function ocultarContenedores() {
            // Ocultar los contenedores con JavaScript
            document.getElementById('contenedor1').style.display = 'none';
            document.getElementById('contenedor2').style.display = 'none';
            document.getElementById('contenedor').style.display = 'none';
        }
    </script>
    <?php
}
}



//Actualizar datos personales
if(isset($_POST['guardar_datos_personales'])){
?>




<div class="additional-container2" id="contenedor2">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>
    <!-- Nuevo contenedor debajo del contenedor principal -->
    <div class="additional-container" id="contenedor1">
        <!-- Contenido del nuevo contenedor aquí -->
    </div>

    <div class="notification-container" id="contenedor">
        <div class="notification-list">
            <!-- Ejemplo de notificaciones -->
            <div class="notification-item">
                <div class="notification-content">
                    <span class="d-block d-md-none" style="position: fixed; left:80%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <span class="d-none d-md-block" style="position: fixed; left:89%; font-size: 14px; color: #0d6efd;" onclick="ocultarContenedores()">Cerrar</span>
                    <strong style="color:black">Notificación</strong>
                    <p style="position: relative; top: 5px; color: #2f2e2e">Datos actualizados. <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#198754" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
</svg></p>
                </div>
            </div>
        </div>
    </div>


    <audio id="notificationSound" preload="auto">
        <source src="../src/files/notificacion/notificacion.mp3" type="audio/mpeg">
        <!-- Agrega otros formatos de audio si es necesario -->
    </audio>
    <script>
        // Muestra la notificación
        document.getElementById('contenedor').style.display = 'block';

        // Reproduce el sonido
        var audio = document.getElementById('notificationSound');
        audio.play();
    </script>

    <script>
        function ocultarContenedores() {
            // Ocultar los contenedores con JavaScript
            document.getElementById('contenedor1').style.display = 'none';
            document.getElementById('contenedor2').style.display = 'none';
            document.getElementById('contenedor').style.display = 'none';
        }
    </script>
                    <?php

}


?>

<script src="../bootstrap/js/script.js"></script>
</body>
</html>