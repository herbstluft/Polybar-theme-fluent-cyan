document.addEventListener("DOMContentLoaded", function() {
    // Cuando la página se haya cargado completamente
    var contenido = document.querySelector(".todo");
    contenido.style.opacity = "1"; // Cambia la opacidad a 1 para activar la animación
});