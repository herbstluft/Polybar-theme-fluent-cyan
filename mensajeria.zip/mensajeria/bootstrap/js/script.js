function toggleDarkLight() {
    var body = document.getElementById("body");
    var currentClass = body.className;
    body.className = currentClass == "dark-mode" ? "light-mode" : "dark-mode";
  }


  const container = document.getElementById('container');

window.addEventListener('scroll', () => {
    if (window.scrollY > 30) { // Cambia este valor según tu necesidad
        container.classList.remove('visible');
        container.classList.add('hidden');
    } else {
        container.classList.remove('hidden');
        container.classList.add('visible');
    }
});



